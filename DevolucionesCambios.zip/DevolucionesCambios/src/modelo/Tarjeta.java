package modelo;


import java.util.*;

/**
 * 
 */
public class Tarjeta extends Pago {

    /**
     * Default constructor
     */
    public Tarjeta() {
    }

    /**
     * 
     */
    private int numero;

    /**
     * 
     */
    private String tipo_tarjeta;

    /**
     * 
     */
    private Date fch_exp;

}