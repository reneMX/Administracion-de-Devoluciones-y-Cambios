package modelo;


import java.util.*;

/**
 * 
 */
public class Pago {

    public Pago(String nombre, double monto) {
        this.nombre = nombre;
        this.monto = monto;
    }

    /**
     * Default constructor
     */
    public Pago() {
    }

    /**
     * 
     */
    private String nombre;

    /**
     * 
     */
    private double monto;

    

    /**
     * @return
     */
    public String damePago() {
        // TODO implement here
        return "";
    }

}